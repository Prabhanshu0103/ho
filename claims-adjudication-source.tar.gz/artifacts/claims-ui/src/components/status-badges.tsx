import { Badge } from "@/components/ui/badge";

export function StatusBadge({ status }: { status?: string | null }) {
  if (!status) return <Badge variant="outline">Unknown</Badge>;
  
  switch (status.toLowerCase()) {
    case 'pending':
      return <Badge className="bg-amber-500 hover:bg-amber-600 text-white border-transparent">Pending</Badge>;
    case 'processing':
      return <Badge className="bg-blue-500 hover:bg-blue-600 text-white border-transparent">Processing</Badge>;
    case 'completed':
      return <Badge className="bg-emerald-600 hover:bg-emerald-700 text-white border-transparent">Completed</Badge>;
    case 'failed':
      return <Badge variant="destructive">Failed</Badge>;
    default:
      return <Badge variant="outline" className="capitalize">{status}</Badge>;
  }
}

export function ClaimStatusBadge({ status }: { status?: string | null }) {
  if (!status) return <span className="text-muted-foreground text-sm">-</span>;
  
  switch (status.toLowerCase()) {
    case 'supported':
      return <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border-emerald-200">Supported</Badge>;
    case 'contradicted':
      return <Badge className="bg-red-100 text-red-800 hover:bg-red-200 border-red-200">Contradicted</Badge>;
    case 'not_enough_information':
      return <Badge className="bg-slate-100 text-slate-800 hover:bg-slate-200 border-slate-200">Needs Info</Badge>;
    default:
      return <Badge variant="outline" className="capitalize">{status.replace(/_/g, ' ')}</Badge>;
  }
}

export function SeverityBadge({ severity }: { severity?: string | null }) {
  if (!severity || severity === 'none' || severity === 'unknown') return null;
  
  switch (severity.toLowerCase()) {
    case 'high':
      return <Badge variant="outline" className="border-red-200 text-red-700 bg-red-50">High Risk</Badge>;
    case 'medium':
      return <Badge variant="outline" className="border-amber-200 text-amber-700 bg-amber-50">Med Risk</Badge>;
    case 'low':
      return <Badge variant="outline" className="border-blue-200 text-blue-700 bg-blue-50">Low Risk</Badge>;
    default:
      return <Badge variant="outline" className="capitalize">{severity}</Badge>;
  }
}
