import { useListClaims } from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge, ClaimStatusBadge, SeverityBadge } from "@/components/status-badges";
import { Skeleton } from "@/components/ui/skeleton";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { Search } from "lucide-react";

export default function ClaimsQueue() {
  const { data: claims, isLoading } = useListClaims();
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");

  const filteredClaims = claims?.filter(c => 
    c.userId.toLowerCase().includes(search.toLowerCase()) || 
    c.id.toString().includes(search) ||
    c.claimObject.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Claims Queue</h1>
          <p className="text-muted-foreground mt-1">Manage and review submitted claims.</p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search by ID, User, Object..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-card"
          />
        </div>
      </div>

      <div className="bg-card border rounded-md shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50 hover:bg-muted/50">
              <TableHead className="w-[80px]">ID</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Object</TableHead>
              <TableHead>Processing State</TableHead>
              <TableHead>Verdict</TableHead>
              <TableHead>Severity</TableHead>
              <TableHead className="text-right">Submitted</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              [...Array(5)].map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-8" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-24 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-4 w-20 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : filteredClaims?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-12 text-muted-foreground">
                  No claims found matching your search.
                </TableCell>
              </TableRow>
            ) : (
              filteredClaims?.map((claim) => (
                <TableRow 
                  key={claim.id}
                  className="cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setLocation(`/claims/${claim.id}`)}
                >
                  <TableCell className="font-mono text-xs">{claim.id}</TableCell>
                  <TableCell className="font-medium">{claim.userId}</TableCell>
                  <TableCell className="capitalize text-muted-foreground">{claim.claimObject}</TableCell>
                  <TableCell><StatusBadge status={claim.status} /></TableCell>
                  <TableCell><ClaimStatusBadge status={claim.claimStatus} /></TableCell>
                  <TableCell><SeverityBadge severity={claim.severity} /></TableCell>
                  <TableCell className="text-right text-sm text-muted-foreground">
                    {new Date(claim.createdAt).toLocaleDateString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
