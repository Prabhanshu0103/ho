import { useParams, useLocation } from "wouter";
import { useGetClaim, getGetClaimQueryKey, useAdjudicateClaim, useDeleteClaim, getListClaimsQueryKey, getGetClaimStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { StatusBadge, ClaimStatusBadge, SeverityBadge } from "@/components/status-badges";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, BrainCircuit, CheckCircle2, Loader2, ShieldAlert, XCircle, Trash2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ClaimDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: claim, isLoading } = useGetClaim(id, { 
    query: { enabled: !!id, queryKey: getGetClaimQueryKey(id) } 
  });
  
  const adjudicateMutation = useAdjudicateClaim();
  const deleteMutation = useDeleteClaim();

  const handleAdjudicate = () => {
    adjudicateMutation.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Adjudication Started", description: "AI is processing the claim evidence." });
        queryClient.invalidateQueries({ queryKey: getGetClaimQueryKey(id) });
        queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetClaimStatsQueryKey() });
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to start adjudication.", variant: "destructive" });
      }
    });
  };

  const handleDelete = () => {
    deleteMutation.mutate({ id }, {
      onSuccess: () => {
        toast({ title: "Claim Deleted", description: "The claim has been permanently removed." });
        queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetClaimStatsQueryKey() });
        setLocation("/claims");
      },
      onError: () => {
        toast({ title: "Error", description: "Failed to delete claim.", variant: "destructive" });
      }
    });
  };

  if (isLoading) {
    return <div className="p-8 max-w-7xl mx-auto space-y-6"><Skeleton className="h-12 w-1/3" /><Skeleton className="h-64 w-full" /></div>;
  }

  if (!claim) {
    return <div className="p-8 text-center text-muted-foreground">Claim not found.</div>;
  }

  const isPending = claim.status === 'pending';
  const isProcessing = claim.status === 'processing';
  const isCompleted = claim.status === 'completed';

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 border-b pb-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-3xl font-bold tracking-tight">Claim #{claim.id}</h1>
            <StatusBadge status={claim.status} />
          </div>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <span className="font-mono bg-muted px-2 py-1 rounded">User: {claim.userId}</span>
            <span className="capitalize">Object: {claim.claimObject}</span>
            <span>Submitted: {new Date(claim.createdAt).toLocaleString()}</span>
          </div>
        </div>
        <div className="flex gap-2">
          {isPending && (
            <Button size="lg" onClick={handleAdjudicate} disabled={adjudicateMutation.isPending} className="bg-primary text-primary-foreground hover:bg-primary/90">
              {adjudicateMutation.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <BrainCircuit className="mr-2 h-4 w-4" />}
              Run AI Adjudication
            </Button>
          )}
          
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="lg" variant="outline" className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground">
                <Trash2 className="h-4 w-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete the claim
                  and remove the data from our servers.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Delete Claim
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      {isProcessing && (
        <Alert className="bg-blue-50 border-blue-200">
          <Loader2 className="h-4 w-4 animate-spin text-blue-600" />
          <AlertTitle className="text-blue-800">Processing</AlertTitle>
          <AlertDescription className="text-blue-700">
            The AI engine is currently analyzing the transcript and photographic evidence. This may take a few moments.
          </AlertDescription>
        </Alert>
      )}

      {claim.errorMessage && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Adjudication Failed</AlertTitle>
          <AlertDescription>{claim.errorMessage}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Evidence & Transcript */}
        <div className="lg:col-span-7 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">User Transcript</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-muted/50 p-4 rounded-md font-mono text-sm leading-relaxed whitespace-pre-wrap">
                {claim.userClaim}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Photographic Evidence</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                {claim.imageUrls.map((url, i) => (
                  <div key={i} className="aspect-video relative rounded-md overflow-hidden bg-muted border">
                    <img 
                      src={url} 
                      alt={`Evidence ${i+1}`} 
                      className="object-cover w-full h-full"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="%23cbd5e1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>';
                      }}
                    />
                    <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
                      IMG_{i+1}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {claim.userHistory && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">User History Context</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{claim.userHistory}</p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Right Column: AI Verdict */}
        <div className="lg:col-span-5 space-y-6">
          <Card className={isCompleted ? "border-primary/20 shadow-md" : "opacity-60"}>
            <CardHeader className="bg-muted/30 border-b pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <BrainCircuit className="h-5 w-5 text-primary" />
                  AI Verdict
                </CardTitle>
                {isCompleted ? <ClaimStatusBadge status={claim.claimStatus} /> : <span className="text-xs text-muted-foreground uppercase font-bold tracking-wider">Awaiting Execution</span>}
              </div>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              {!isCompleted ? (
                <div className="text-center py-8 text-muted-foreground flex flex-col items-center">
                  <ShieldAlert className="h-12 w-12 mb-3 opacity-20" />
                  <p className="text-sm">Adjudication results will appear here<br/>once processing is complete.</p>
                </div>
              ) : (
                <>
                  <div className="space-y-1">
                    <h4 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Justification</h4>
                    <p className="text-sm leading-relaxed">{claim.claimStatusJustification}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 py-4 border-y">
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Issue Type</h4>
                      <p className="font-medium capitalize">{claim.issueType || "Unknown"}</p>
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Object Part</h4>
                      <p className="font-medium capitalize">{claim.objectPart || "N/A"}</p>
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Severity</h4>
                      <SeverityBadge severity={claim.severity} />
                    </div>
                    <div>
                      <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-1">Evidence Std</h4>
                      <div className="flex items-center gap-1.5">
                        {claim.evidenceStandardMet ? (
                          <><CheckCircle2 className="h-4 w-4 text-emerald-500" /><span className="text-sm font-medium">Met</span></>
                        ) : (
                          <><XCircle className="h-4 w-4 text-red-500" /><span className="text-sm font-medium">Not Met</span></>
                        )}
                      </div>
                    </div>
                  </div>

                  {!claim.evidenceStandardMet && claim.evidenceStandardMetReason && (
                    <div className="bg-red-50 text-red-900 p-3 rounded-md border border-red-100 text-sm">
                      <strong className="block mb-1">Standard Failure Reason:</strong>
                      {claim.evidenceStandardMetReason}
                    </div>
                  )}

                  {claim.riskFlags && claim.riskFlags.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-semibold uppercase tracking-wider text-red-600 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Risk Flags Detected
                      </h4>
                      <ul className="space-y-1">
                        {claim.riskFlags.map((flag, idx) => (
                          <li key={idx} className="text-sm flex items-start gap-2 bg-red-50/50 p-2 rounded border border-red-100">
                            <span className="text-red-500 mt-0.5">•</span>
                            <span className="text-foreground">{flag}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
