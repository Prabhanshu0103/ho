import { useState } from "react";
import { useLocation } from "wouter";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useCreateClaim, getListClaimsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Trash2, Plus, Loader2 } from "lucide-react";

const formSchema = z.object({
  userId: z.string().min(1, "User ID is required"),
  claimObject: z.enum(["car", "laptop", "package"], {
    required_error: "Please select an object type",
  }),
  userClaim: z.string().min(10, "Claim description must be at least 10 characters"),
  imageUrls: z.array(z.object({ value: z.string().url("Must be a valid URL") })).min(1, "At least one image is required"),
  userHistory: z.string().optional(),
});

export default function NewClaim() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const createClaim = useCreateClaim();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: "",
      claimObject: undefined,
      userClaim: "",
      imageUrls: [{ value: "" }],
      userHistory: "",
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "imageUrls",
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createClaim.mutate({
      data: {
        userId: values.userId,
        claimObject: values.claimObject,
        userClaim: values.userClaim,
        imageUrls: values.imageUrls.map(img => img.value),
        userHistory: values.userHistory || null,
      }
    }, {
      onSuccess: (claim) => {
        queryClient.invalidateQueries({ queryKey: getListClaimsQueryKey() });
        toast({
          title: "Claim Submitted",
          description: `Claim #${claim.id} has been created and is pending adjudication.`,
        });
        setLocation(`/claims/${claim.id}`);
      },
      onError: (error) => {
        toast({
          title: "Error submitting claim",
          description: "An unexpected error occurred.",
          variant: "destructive",
        });
      }
    });
  }

  return (
    <div className="p-8 max-w-3xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Submit New Claim</h1>
        <p className="text-muted-foreground mt-1">Enter incident details and evidence to queue for adjudication.</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Subject Details</CardTitle>
              <CardDescription>Basic information about the claimant and object.</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="userId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Identifier</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g. usr_12345" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="claimObject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Object Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select object type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="car">Vehicle (Car)</SelectItem>
                        <SelectItem value="laptop">Electronics (Laptop)</SelectItem>
                        <SelectItem value="package">Delivery (Package)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Evidence & Transcript</CardTitle>
              <CardDescription>Provide the conversational claim transcript and photographic evidence.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="userClaim"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>User Claim Transcript</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Detailed description of the incident as reported by the user..." 
                        className="min-h-[120px] font-mono text-sm"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <Label>Photographic Evidence (URLs)</Label>
                {fields.map((field, index) => (
                  <FormField
                    key={field.id}
                    control={form.control}
                    name={`imageUrls.${index}.value`}
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="flex items-center gap-2">
                            <Input placeholder="https://example.com/image.jpg" {...field} />
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="icon"
                              className="shrink-0 text-destructive"
                              onClick={() => remove(index)}
                              disabled={fields.length === 1}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ))}
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm"
                  onClick={() => append({ value: "" })}
                  className="mt-2"
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Image URL
                </Button>
              </div>

              <FormField
                control={form.control}
                name="userHistory"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Prior User History (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Any relevant past claims or flagged behavior..." 
                        className="font-mono text-sm"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <div className="flex justify-end">
            <Button type="submit" disabled={createClaim.isPending} size="lg">
              {createClaim.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Submit for Adjudication
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}
