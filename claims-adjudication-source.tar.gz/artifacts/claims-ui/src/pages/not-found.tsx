import { Link } from "wouter";
import { AlertCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <Card className="w-full max-w-md border-border shadow-lg">
        <CardContent className="pt-10 pb-10 flex flex-col items-center text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mb-6" />
          <h1 className="text-3xl font-bold tracking-tight text-foreground mb-2">404</h1>
          <h2 className="text-xl font-semibold text-foreground mb-4">Record Not Found</h2>
          <p className="text-sm text-muted-foreground mb-8 max-w-xs mx-auto">
            The requested claim or system resource could not be located in the adjudication database.
          </p>
          <Link href="/">
            <Button size="lg" className="w-full sm:w-auto">
              Return to Dashboard
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
