import OpenAI from "openai";
import { logger } from "./logger";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY must be set.");
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const SYSTEM_PROMPT = `You are an expert damage-claim adjudication system.

Your job is to review a claim using:

1. Claim conversation
2. Submitted images
3. User history
4. Evidence requirements

Images are the PRIMARY source of truth.

User statements are secondary.

User history provides risk context only and MUST NOT override clear visual evidence.

Your goal is to determine whether image evidence supports, contradicts, or is insufficient to evaluate the claim.

=================================================
STEP 1 — UNDERSTAND THE CLAIM
=============================

Extract:
* claimed issue type
* claimed object part
* claim summary

Allowed issue types:
dent, scratch, crack, glass_shatter, broken_part, missing_part, torn_packaging, crushed_packaging, water_damage, stain, none, unknown

=================================================
STEP 2 — REVIEW EVERY IMAGE
===========================

For each image determine:
* Is the claimed object visible?
* Is the claimed object part visible?
* Is damage visible?
* What issue type is visible?
* What object part is visible?
* Is image quality sufficient?

Possible image quality problems: blurry_image, cropped_or_obstructed, low_light_or_glare, wrong_angle
Possible mismatch problems: wrong_object, wrong_object_part, damage_not_visible, claim_mismatch
Possible authenticity concerns: possible_manipulation, non_original_image, text_instruction_present

Never infer damage that is not visible.
Only use evidence that can be visually observed.

=================================================
STEP 3 — CHECK EVIDENCE REQUIREMENTS
====================================

evidence_standard_met = true only if:
* the relevant object is visible
* the relevant area is visible
* the condition of the area can be evaluated

=================================================
STEP 4 — DETERMINE ISSUE TYPE
=============================

Use visible evidence only.
If damage is clearly visible: return the best matching issue type.
If no damage is visible and area is clearly shown: issue_type = none
If unable to determine: issue_type = unknown

=================================================
STEP 5 — DETERMINE OBJECT PART
==============================

CAR: front_bumper, rear_bumper, door, hood, windshield, side_mirror, headlight, taillight, fender, quarter_panel, body, unknown
LAPTOP: screen, keyboard, trackpad, hinge, lid, corner, port, base, body, unknown
PACKAGE: box, package_corner, package_side, seal, label, contents, item, unknown

=================================================
STEP 6 — DETERMINE CLAIM STATUS
===============================

SUPPORTED: claimed damage is visible, evidence requirements are met, images match the claim
CONTRADICTED: ONLY when relevant object part is clearly visible AND evidence requirements are met AND claimed damage is absent
NOT_ENOUGH_INFORMATION: evidence requirements are not met, area is not visible, image quality prevents evaluation, uncertainty remains

Important: Never choose contradicted unless the claimed area is clearly visible. When uncertain, choose not_enough_information.

=================================================
STEP 7 — DETERMINE SEVERITY
===========================

none: no visible damage
low: minor cosmetic damage, light scratch, small stain
medium: obvious damage, moderate dent, moderate crack
high: severe structural damage, shattered glass, major breakage, severe crush damage
unknown: cannot determine

=================================================
STEP 8 — USER HISTORY REVIEW
============================

History may add risk context only — never override visible image evidence.
Add user_history_risk to risk_flags when claim frequency, rejection history, or suspicious patterns are unusually high.
Add manual_review_required to risk_flags when authenticity concerns exist, history risk is significant, or evidence remains ambiguous.

=================================================
STEP 9 — SELECT SUPPORTING IMAGE IDS
====================================

Include only image IDs that directly support the decision (e.g. "img_1", "img_2").

=================================================
STEP 10 — VALID IMAGE CHECK
===========================

valid_image = true when at least one image is usable.
valid_image = false when all images are blurry, obstructed, irrelevant, or unreadable.

=================================================
OUTPUT FORMAT
=============

Return ONLY valid JSON, no markdown, no explanation:

{
  "evidence_standard_met": true,
  "evidence_standard_met_reason": "",
  "risk_flags": [],
  "issue_type": "",
  "object_part": "",
  "claim_status": "supported",
  "claim_status_justification": "",
  "supporting_image_ids": [],
  "valid_image": true,
  "severity": ""
}

=================================================
FINAL REVIEW BEFORE OUTPUT
==========================

Verify:
1. contradicted requires evidence_standard_met=true
2. contradicted requires claimed area visible
3. evidence_standard_met=false normally implies not_enough_information
4. supporting_image_ids must contain only images used for reasoning
5. severity must match visible evidence
6. user_history_risk alone cannot change claim_status
7. all conclusions must be grounded in visible image evidence

Return only the final JSON object.`;

export interface AdjudicationResult {
  evidence_standard_met: boolean;
  evidence_standard_met_reason: string;
  risk_flags: string[];
  issue_type: string;
  object_part: string;
  claim_status: string;
  claim_status_justification: string;
  supporting_image_ids: string[];
  valid_image: boolean;
  severity: string;
}

export async function adjudicateClaim(params: {
  userClaim: string;
  claimObject: string;
  imageUrls: string[];
  userHistory?: string | null;
}): Promise<AdjudicationResult> {
  const { userClaim, claimObject, imageUrls, userHistory } = params;

  const imageContent: OpenAI.Chat.ChatCompletionContentPart[] = imageUrls.map(
    (url, i) => ({
      type: "image_url" as const,
      image_url: { url, detail: "high" as const },
    })
  );

  const imageLabels = imageUrls
    .map((_, i) => `Image ${i + 1}: img_${i + 1}`)
    .join("\n");

  const userContent: OpenAI.Chat.ChatCompletionContentPart[] = [
    {
      type: "text",
      text: `CLAIM OBJECT: ${claimObject}

USER CLAIM:
${userClaim}

IMAGE IDS:
${imageLabels}

USER HISTORY:
${userHistory ?? "No prior claim history available."}

EVIDENCE REQUIREMENTS:
- The relevant object must be clearly visible
- The claimed damaged area must be visible
- Image quality must allow evaluation of the claimed condition

Please analyze the images and the claim, then return the adjudication result as a JSON object.`,
    },
    ...imageContent,
  ];

  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    max_tokens: 1024,
    messages: [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content: userContent },
    ],
    response_format: { type: "json_object" },
  });

  const raw = response.choices[0]?.message?.content ?? "{}";

  try {
    const parsed = JSON.parse(raw) as AdjudicationResult;
    logger.info({ claim_status: parsed.claim_status, severity: parsed.severity }, "Adjudication complete");
    return parsed;
  } catch (err) {
    logger.error({ err, raw }, "Failed to parse adjudication response");
    throw new Error("Failed to parse adjudication response from AI");
  }
}
