import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, claimsTable } from "@workspace/db";
import {
  ListClaimsQueryParams,
  CreateClaimBody,
  GetClaimParams,
  DeleteClaimParams,
  AdjudicateClaimParams,
} from "@workspace/api-zod";
import { adjudicateClaim } from "../lib/adjudicate";

const router: IRouter = Router();

// GET /claims
router.get("/claims", async (req, res): Promise<void> => {
  const parsed = ListClaimsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let query = db.select().from(claimsTable).$dynamic();

  if (parsed.data.status) {
    query = query.where(eq(claimsTable.status, parsed.data.status));
  } else if (parsed.data.claimStatus) {
    query = query.where(eq(claimsTable.claimStatus, parsed.data.claimStatus));
  }

  const claims = await query.orderBy(sql`${claimsTable.createdAt} DESC`);
  res.json(claims);
});

// POST /claims
router.post("/claims", async (req, res): Promise<void> => {
  const parsed = CreateClaimBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { userId, userClaim, claimObject, imageUrls, userHistory } = parsed.data;

  const [claim] = await db
    .insert(claimsTable)
    .values({
      userId,
      userClaim,
      claimObject,
      imageUrls,
      userHistory: userHistory ?? null,
      status: "pending",
    })
    .returning();

  res.status(201).json(claim);
});

// GET /claims/stats — must come before /:id
router.get("/claims/stats", async (_req, res): Promise<void> => {
  const rows = await db.select().from(claimsTable);

  const stats = {
    total: rows.length,
    pending: rows.filter((r) => r.status === "pending").length,
    processing: rows.filter((r) => r.status === "processing").length,
    completed: rows.filter((r) => r.status === "completed").length,
    failed: rows.filter((r) => r.status === "failed").length,
    supported: rows.filter((r) => r.claimStatus === "supported").length,
    contradicted: rows.filter((r) => r.claimStatus === "contradicted").length,
    notEnoughInformation: rows.filter((r) => r.claimStatus === "not_enough_information").length,
    bySeverity: {} as Record<string, number>,
    byObject: {} as Record<string, number>,
  };

  for (const row of rows) {
    if (row.severity) {
      stats.bySeverity[row.severity] = (stats.bySeverity[row.severity] ?? 0) + 1;
    }
    if (row.claimObject) {
      stats.byObject[row.claimObject] = (stats.byObject[row.claimObject] ?? 0) + 1;
    }
  }

  res.json(stats);
});

// GET /claims/:id
router.get("/claims/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = GetClaimParams.safeParse({ id: parseInt(rawId, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [claim] = await db
    .select()
    .from(claimsTable)
    .where(eq(claimsTable.id, parsed.data.id));

  if (!claim) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  res.json(claim);
});

// DELETE /claims/:id
router.delete("/claims/:id", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = DeleteClaimParams.safeParse({ id: parseInt(rawId, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [deleted] = await db
    .delete(claimsTable)
    .where(eq(claimsTable.id, parsed.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  res.sendStatus(204);
});

// POST /claims/:id/adjudicate
router.post("/claims/:id/adjudicate", async (req, res): Promise<void> => {
  const rawId = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const parsed = AdjudicateClaimParams.safeParse({ id: parseInt(rawId, 10) });
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [claim] = await db
    .select()
    .from(claimsTable)
    .where(eq(claimsTable.id, parsed.data.id));

  if (!claim) {
    res.status(404).json({ error: "Claim not found" });
    return;
  }

  if (claim.status === "completed" || claim.status === "processing") {
    res.status(409).json({ error: `Claim is already ${claim.status}` });
    return;
  }

  // Mark as processing
  await db
    .update(claimsTable)
    .set({ status: "processing", updatedAt: new Date() })
    .where(eq(claimsTable.id, claim.id));

  try {
    const result = await adjudicateClaim({
      userClaim: claim.userClaim,
      claimObject: claim.claimObject,
      imageUrls: claim.imageUrls as string[],
      userHistory: claim.userHistory,
    });

    const [updated] = await db
      .update(claimsTable)
      .set({
        status: "completed",
        claimStatus: result.claim_status,
        evidenceStandardMet: result.evidence_standard_met,
        evidenceStandardMetReason: result.evidence_standard_met_reason,
        riskFlags: result.risk_flags,
        issueType: result.issue_type,
        objectPart: result.object_part,
        claimStatusJustification: result.claim_status_justification,
        supportingImageIds: result.supporting_image_ids,
        validImage: result.valid_image,
        severity: result.severity,
        updatedAt: new Date(),
      })
      .where(eq(claimsTable.id, claim.id))
      .returning();

    res.json(updated);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    await db
      .update(claimsTable)
      .set({ status: "failed", errorMessage: msg, updatedAt: new Date() })
      .where(eq(claimsTable.id, claim.id));

    res.status(500).json({ error: msg });
  }
});

export default router;
