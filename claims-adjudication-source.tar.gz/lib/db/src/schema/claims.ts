import { pgTable, serial, text, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const claimsTable = pgTable("claims", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  userClaim: text("user_claim").notNull(),
  claimObject: text("claim_object").notNull(),
  imageUrls: jsonb("image_urls").$type<string[]>().notNull().default([]),
  userHistory: text("user_history"),
  status: text("status").notNull().default("pending"),
  claimStatus: text("claim_status"),
  evidenceStandardMet: boolean("evidence_standard_met"),
  evidenceStandardMetReason: text("evidence_standard_met_reason"),
  riskFlags: jsonb("risk_flags").$type<string[]>(),
  issueType: text("issue_type"),
  objectPart: text("object_part"),
  claimStatusJustification: text("claim_status_justification"),
  supportingImageIds: jsonb("supporting_image_ids").$type<string[]>(),
  validImage: boolean("valid_image"),
  severity: text("severity"),
  errorMessage: text("error_message"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertClaimSchema = createInsertSchema(claimsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertClaim = z.infer<typeof insertClaimSchema>;
export type Claim = typeof claimsTable.$inferSelect;
